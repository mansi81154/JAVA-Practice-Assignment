/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mansi
 */
public class Asterisk {
   public static void main(String as[])
   {
       for(int i=1;i<=5;i++)
       {
           for(int j=5;j>=i;j--)
           {
               System.out.print("*");
           }
           System.out.println();
       }
   }
}
