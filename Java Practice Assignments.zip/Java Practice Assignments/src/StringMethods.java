/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mansi
 */
public class StringMethods {
    public static void main(String as[])
    {
        String s1="javatpoint";  
        String s2="javatpoint";  
        String s3="JAVATPOINT";  
        String s4="python"; 
        String s5="";
        System.out.println(s1.equals(s2));//true because content and case is same  
        System.out.println(s1.equals(s3));//false because case is not same  
        System.out.println(s1.equals(s4));//false because content is not same
        System.out.println(s5.isEmpty());  
        System.out.println(s2.isEmpty()); 
        System.out.println("string length is: "+s1.length());
        System.out.println("string length is: "+s2.length()); 
        String replaceString=s1.replace('a','e');//replaces all occurrences of 'a' to 'e'  
        System.out.println(replaceString); 
        String s6="java string split method by javatpoint";  
        String[] words=s6.split("\\s");//splits the string based on whitespace  
       //using java foreach loop to print elements of string array  
        for(String w:words){  
        System.out.println(w); 
        System.out.println(s6.startsWith("ja"));  
        System.out.println(s6.startsWith("java string")); 
        }
        System.out.println(s1.substring(2,4));//returns va  
        String s1lower=s1.toLowerCase();  
        System.out.println(s1lower);
        String s1upper=s1.toUpperCase();  
        System.out.println(s1upper); 
        
        String s7 ="  hello java string   ";  
        System.out.println(s7.length());  
        System.out.println(s7); //Without trim()  
        String tr = s7.trim();  
        System.out.println(tr.length());  
        System.out.println(tr); //With trim()  
        int value=30;  
        String s8=String.valueOf(value);  
        System.out.println(s8+10);//concatenating string with 10  
        System.out.println(s1.compareTo(s2));
        s1.concat("is immutable");  
        boolean isContains = s6.contains("Javatpoint");
        System.out.println(isContains);  
        
    }
}
