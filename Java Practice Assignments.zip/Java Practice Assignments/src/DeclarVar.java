/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mansi
 */
import java.util.*;
public class DeclarVar {
    public static void main(String as[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any integer value:");
        int a=sc.nextInt();
        System.out.println("Enter any float value:");
        float b=sc.nextFloat();
      
        Scanner sc2=new Scanner(System.in);
        System.out.println("Enter 2 String value:");
        String s1=sc2.nextLine();
        String s2=sc2.nextLine();
      
        
    }
}
