/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mansi
 */

// With the help of interface we can acieve multiple inheritance...

interface Interface1
{
   public void show();
}
interface Interface2
{
   public void show();
}
class SubClass implements Interface1, Interface2
{
   public void show()
   {
       System.out.println("A class can implements more than one interfaces");
   }
   public static void main(String args[]){
    SubClass obj = new SubClass();
    obj.show();
   }
}
