/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mansi
 */
import java.util.*;
public class SwitchControl {
    public static void main(String as[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1 for check Fibonacci\n Enter 2 for check prime\n Enter 3 for Palindrome\n Enter 4 for Factorial\n Enter 5 for Armstrong");
        int choice=sc.nextInt();
        switch(choice)
        {
            case 1: //Fibonacci
                Scanner sc1 = new Scanner(System.in);
         
                System.out.println("Enter positive number :");
         
                 int inputNumber = sc1.nextInt();
         
                 int firstTerm = 0;
         
                  int secondTerm = 1;
         
                  int thirdTerm = 0;
         
                 while (thirdTerm < inputNumber)
                {
                        thirdTerm = firstTerm + secondTerm;
              
                        firstTerm = secondTerm;
             
                        secondTerm = thirdTerm;
                }
         
                  if(thirdTerm == inputNumber)
                  {
                        System.out.println("Number belongs to Fibonacci series");
                  }
                  else
                  {
                      System.out.println("Number doesn't belongs to Fibonacci series");
                  }
                  break;
                
                
            case 2: //Prime
                int i,m=0,flag=0;  
                System.out.println("enter the number to be checked for prime: ");
                Scanner sc3=new Scanner(System.in);
                int n=sc3.nextInt();//it is the number to be checked    
                m=n/2;      
                if(n==0||n==1){  
                  System.out.println(n+" is not prime number");      
                }else{  
                for(i=2;i<=m;i++){      
                if(n%i==0){      
                 System.out.println(n+" is not prime number");      
                 flag=1;      
                 break;      
                }      
               }      
               if(flag==0)  { System.out.println(n+" is prime number"); }  
               }
               break;
                
                
            case 3://Palindrome 
                    int r,sum=0,temp; 
                    Scanner sc4=new Scanner(System.in);
                    System.out.println("Enter no. for check Palindrome");
                    int palin=sc.nextInt();//It is the number variable to be checked for palindrome  
  
                    temp=palin;    
                    while(palin>0){    
                       r=palin%10;  //getting remainder  
                       sum=(sum*10)+r;    
                        palin=palin/10;    
                       }    
                     if(temp==sum)    
                         System.out.println("palindrome number ");    
                     else    
                     System.out.println("not palindrome");  
                     break;
                
                
            case 4: //Factorial
                    int init,fact=1; 
                    Scanner sc5=new Scanner(System.in);
                    System.out.println("Enter no. for calculate factorial");
                    int number=sc5.nextInt();//It is the number to calculate factorial    
                   for(init=1;init<=number;init++){    
                     fact=fact*init;    
                   }    
                   System.out.println("Factorial of "+number+" is: "+fact);  
                break;
              
            case 5: //Armstrong
                   int c=0,a,tempp;  
                   int num2=153;//It is the number to check armstrong  
                   tempp=num2;  
                   while(num2>0)  
                   {  
                        a=num2%10;  
                        num2=num2/10;  
                        c=c+(a*a*a);  
                   }  
                     if(tempp==c)  
                          System.out.println("armstrong number");   
                    else  
                       System.out.println("Not armstrong number");   
                
                
            default:System.out.println("Wrong Input");    
           } //end of switch
    }
}
