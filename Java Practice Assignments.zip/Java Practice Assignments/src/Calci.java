/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mansi
 */
import java.util.*;
public class Calci {
    public static void main(String as[])
    {  
        double add,sub,mul,div,mod;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter First number: ");
        double num1=sc.nextDouble();
        System.out.println("Enter Second number");
        double num2=sc.nextDouble();
        System.out.println("enter 1 for Addition\n 2 for Subraction\n 3 for Multiply\n 4 for Division\n 5 for Modulus");
        int store=sc.nextInt();
        switch(store)
        {
            
            case 1:add= num1+num2;
                System.out.println("Addition is: "+add);
                break;
            case 2:sub= num1-num2;
                System.out.println("Subtraction is: "+sub);
                break;
            case 3:mul= num1*num2;
                System.out.println("Multiplication is: "+mul);
                break;
            case 4:div= num1/num2;
                System.out.println("Division is: "+div);
                break; 
            case 5:mod= num1%num2;
                System.out.println("Modulus is: "+mod);
                break; 
            default:System.out.println("Wrong Input");
                break;
        }
       
    }
}
